$(document).ready(function() {
    $("#login").click(function(e) {
        e.preventDefault();
        var url = $(this).data('target');
        location.replace(url);
    })
})
